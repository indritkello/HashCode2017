﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashCode
{
    public class Cache
    {
        public int CacheId { get; set; }
        public int CacheSize { get; set; }
    }
}
